#include "PluginProcessor.h"
#include "PluginEditor.h"

const int kPatterns[24][4] = {
    {0,1,2,3},{0,1,3,2},{0,2,1,3},{0,2,3,1},{0,3,1,2},{0,3,2,1},
    {1,0,2,3},{1,0,3,2},{1,2,0,3},{1,2,3,0},{1,3,0,2},{1,3,2,0},
    {2,0,1,3},{2,0,3,1},{2,1,0,3},{2,1,3,0},{2,3,0,1},{2,3,1,0},
    {3,0,1,2},{3,0,2,1},{3,1,0,2},{3,1,2,0},{3,2,0,1},{3,2,1,0} };

juce::AudioProcessor::BusesProperties ChaosTriggerProcessor::makeBuses()
{
    auto b = juce::AudioProcessor::BusesProperties();
    for (int i = 0; i < kNumLanes; ++i)
        b = b.withOutput ("Lane " + juce::String (i + 1), juce::AudioChannelSet::stereo(), i == 0);
    return b;
}

ChaosTriggerProcessor::ChaosTriggerProcessor()
    : AudioProcessor (makeBuses()),
      apvts (*this, nullptr, "STATE", createLayout())
{
    formatManager.registerBasicFormats();
    for (auto& p : playPos) p = 0.0f;
    for (auto& e : envLevel) e = 0.0f;
}

juce::AudioProcessorValueTreeState::ParameterLayout ChaosTriggerProcessor::createLayout()
{
    using namespace juce;
    AudioProcessorValueTreeState::ParameterLayout l;
    auto addFx = [&l] (const String& pre, const String& n)
    {
        l.add (std::make_unique<AudioParameterFloat>(ParameterID { pre + "dist", 1 }, n + "Distortion", NormalisableRange<float> (0, 1), 0.0f));
        l.add (std::make_unique<AudioParameterFloat>(ParameterID { pre + "haas", 1 }, n + "Haas (ms)", NormalisableRange<float> (0, 100, 0.1f), 0.0f));
        l.add (std::make_unique<AudioParameterFloat>(ParameterID { pre + "crush", 1 }, n + "Bitcrush (bits)", NormalisableRange<float> (1, 24, 0.01f), 24.0f));
        l.add (std::make_unique<AudioParameterFloat>(ParameterID { pre + "smash", 1 }, n + "Smash", NormalisableRange<float> (0, 1), 0.0f));
    };
    addFx ("m_", "Master ");
    l.add (std::make_unique<AudioParameterBool> (ParameterID { "m_ring", 1 }, "Ring Mod", false));
    l.add (std::make_unique<AudioParameterFloat>(ParameterID { "m_ringHz", 1 }, "Ring Mod Freq",
                                                 NormalisableRange<float> (20.0f, 4000.0f, 0.1f, 0.3f), 440.0f));
    l.add (std::make_unique<AudioParameterChoice>(ParameterID { "m_fmode", 1 }, "Filter Mode",
                                                  StringArray { "Off", "Low Pass 24", "Band Pass 6", "High Pass 12" }, 0));
    l.add (std::make_unique<AudioParameterFloat>(ParameterID { "m_cutoff", 1 }, "Cutoff",
                                                 NormalisableRange<float> (20.0f, 20000.0f, 0.1f, 0.25f), 20000.0f));
    l.add (std::make_unique<AudioParameterFloat>(ParameterID { "m_res", 1 }, "Resonance", NormalisableRange<float> (0, 1), 0.0f));

    l.add (std::make_unique<AudioParameterInt>  (ParameterID { "pitch", 1 }, "Pitch", -12, 12, 0));
    l.add (std::make_unique<AudioParameterBool> (ParameterID { "legato", 1 }, "Legato", false));
    l.add (std::make_unique<AudioParameterBool> (ParameterID { "free", 1 }, "Free Run", false));
    l.add (std::make_unique<AudioParameterFloat>(ParameterID { "freeRate", 1 }, "Free Rate",
                                                 NormalisableRange<float> (0.5f, 40.0f, 0.01f, 0.4f), 8.0f));
    l.add (std::make_unique<AudioParameterChoice>(ParameterID { "division", 1 }, "Chaos Divider",
                                                  StringArray { "1/128","1/64","1/32","1/16","1/8","1/4","1/2","1/1" }, 3));
    l.add (std::make_unique<AudioParameterChoice>(ParameterID { "feel", 1 }, "Feel",
                                                  StringArray { "Straight","Triplet","Dotted","Swing" }, 0));
    l.add (std::make_unique<AudioParameterFloat>(ParameterID { "swing", 1 }, "Swing Amount",
                                                 NormalisableRange<float> (0.0f, 0.75f), 0.33f));
    StringArray pats;
    for (int i = 0; i < 24; ++i)
    {
        String s; for (int k = 0; k < 4; ++k) s << (kPatterns[i][k] + 1);
        pats.add (String (i + 1) + " - " + s);
    }
    pats.add ("66 - RANDOOM");
    l.add (std::make_unique<AudioParameterChoice>(ParameterID { "pattern", 1 }, "Chaos Picker", pats, 0));

    for (int i = 0; i < kNumLanes; ++i)
    {
        auto n = "Lane " + String (i + 1) + " ";
        NormalisableRange<float> t (0.0f, 4.0f, 0.001f, 0.3f);
        l.add (std::make_unique<AudioParameterFloat>(ParameterID { laneId (i, "a"), 1 }, n + "Attack",  t, 0.002f));
        l.add (std::make_unique<AudioParameterFloat>(ParameterID { laneId (i, "d"), 1 }, n + "Decay",   t, 0.1f));
        l.add (std::make_unique<AudioParameterFloat>(ParameterID { laneId (i, "s"), 1 }, n + "Sustain", NormalisableRange<float> (0, 1), 1.0f));
        l.add (std::make_unique<AudioParameterFloat>(ParameterID { laneId (i, "r"), 1 }, n + "Release", t, 0.02f));
        l.add (std::make_unique<AudioParameterFloat>(ParameterID { laneId (i, "pan"), 1 }, n + "Pan", NormalisableRange<float> (-1, 1), 0.0f));
        l.add (std::make_unique<AudioParameterFloat>(ParameterID { laneId (i, "vol"), 1 }, n + "Volume",
                                                     NormalisableRange<float> (-60.0f, 6.0f, 0.1f, 2.0f), 0.0f));
        l.add (std::make_unique<AudioParameterBool> (ParameterID { laneId (i, "power"), 1 }, n + "Power", true));
        l.add (std::make_unique<AudioParameterBool> (ParameterID { laneId (i, "mono"), 1 }, n + "Mono", false));
        l.add (std::make_unique<AudioParameterBool> (ParameterID { laneId (i, "rev"), 1 }, n + "Reverse", false));
        addFx (laneId (i, ""), n);
        l.add (std::make_unique<AudioParameterChoice>(ParameterID { laneId (i, "chorus"), 1 }, n + "Chorus",
                                                      StringArray { "Off", "I", "II", "I+II" }, 0));
    }
    return l;
}

bool ChaosTriggerProcessor::isBusesLayoutSupported (const BusesLayout& layout) const
{
    for (auto& b : layout.outputBuses)
        if (! b.isDisabled() && b != juce::AudioChannelSet::stereo())
            return false;
    return layout.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}

void ChaosTriggerProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    sr = sampleRate;
    for (int i = 0; i < kNumLanes; ++i)
    {
        env[(size_t) i].setSampleRate (sr);
        env[(size_t) i].reset();
        gainL[(size_t) i].reset (sr, 0.02);
        gainR[(size_t) i].reset (sr, 0.02);
    }
    running = false;
    heldNotes = 0;
    laneBuf.setSize (kNumLanes * 2, juce::jmax (1, samplesPerBlock));
    for (auto& f : laneFx) f.prepare (sr, samplesPerBlock);
    for (auto& f : masterFx) f.prepare (sr, samplesPerBlock);
}

FxSettings ChaosTriggerProcessor::readFx (const juce::String& pre, bool master) const
{
    auto v = [this, &pre] (const char* id) { return apvts.getRawParameterValue (pre + id)->load(); };
    FxSettings s;
    s.dist = v ("dist"); s.haasMs = v ("haas"); s.bits = v ("crush"); s.smash = v ("smash");
    if (master)
    {
        s.ring = v ("ring") > 0.5f; s.ringHz = v ("ringHz");
        s.filterMode = (int) v ("fmode"); s.cutoff = v ("cutoff"); s.res = v ("res");
    }
    else s.chorus = (int) v ("chorus");
    return s;
}

bool ChaosTriggerProcessor::loadSample (int lane, const juce::File& file)
{
    std::unique_ptr<juce::AudioFormatReader> reader (formatManager.createReaderFor (file));
    if (reader == nullptr || reader->lengthInSamples <= 0)
        return false;

    auto s = std::make_shared<LaneSample>();
    const auto len = (int) std::min<juce::int64> (reader->lengthInSamples, (juce::int64) (reader->sampleRate * 600));
    s->buffer.setSize (2, len);
    reader->read (&s->buffer, 0, len, 0, true, true);
    if (reader->numChannels == 1)
        s->buffer.copyFrom (1, 0, s->buffer, 0, 0, len);
    s->sampleRate = reader->sampleRate;
    s->name = file.getFileName();
    s->path = file.getFullPathName();

    std::shared_ptr<const LaneSample> c = s;
    std::atomic_store (&samples[(size_t) lane], c);
    return true;
}

double ChaosTriggerProcessor::currentStepLengthSamples (int idx)
{
    const bool freeRun = apvts.getRawParameterValue ("free")->load() > 0.5f;
    double len;
    if (freeRun)
    {
        len = sr / (double) apvts.getRawParameterValue ("freeRate")->load();
    }
    else
    {
        double bpm = 120.0;
        if (auto* ph = getPlayHead())
            if (auto pos = ph->getPosition())
                if (auto b = pos->getBpm())
                    bpm = *b;
        static const double divBeats[] = { 4.0/128, 4.0/64, 4.0/32, 4.0/16, 4.0/8, 4.0/4, 4.0/2, 4.0 };
        const int d = (int) apvts.getRawParameterValue ("division")->load();
        len = divBeats[juce::jlimit (0, 7, d)] * 60.0 / bpm * sr;
    }

    switch ((int) apvts.getRawParameterValue ("feel")->load())
    {
        case 1: len *= 2.0 / 3.0; break;                       // triplet
        case 2: len *= 1.5; break;                             // dotted
        case 3: {                                              // swing: long-short pairs
            const double sw = apvts.getRawParameterValue ("swing")->load();
            len *= (idx % 2 == 0) ? (1.0 + sw) : (1.0 - sw);
            break; }
        default: break;
    }
    return juce::jmax (16.0, len);
}

void ChaosTriggerProcessor::advanceStep()
{
    // Lanes that can be played: powered and loaded.
    auto playable = [this] (int lane)
    {
        return apvts.getRawParameterValue (laneId (lane, "power"))->load() > 0.5f
            && std::atomic_load (&samples[(size_t) lane]) != nullptr;
    };

    const int pat = (int) apvts.getRawParameterValue ("pattern")->load();
    int next = -1;

    if (pat >= 24)
    {
        int cands[kNumLanes]; int n = 0;
        for (int i = 0; i < kNumLanes; ++i) if (playable (i)) cands[n++] = i;
        if (n > 0) next = cands[rng.nextInt (n)];
    }
    else
    {
        for (int tries = 0; tries < 4; ++tries)
        {
            const int lane = kPatterns[pat][stepIndex];
            stepIndex = (stepIndex + 1) % 4;
            if (playable (lane)) { next = lane; break; }   // skip off/empty lanes
        }
    }

    if (next != currentLane)
    {
        if (currentLane >= 0) env[(size_t) currentLane].noteOff();
    }
    if (next >= 0)
    {
        auto& e = env[(size_t) next];
        juce::ADSR::Parameters p;
        p.attack  = apvts.getRawParameterValue (laneId (next, "a"))->load();
        p.decay   = apvts.getRawParameterValue (laneId (next, "d"))->load();
        p.sustain = apvts.getRawParameterValue (laneId (next, "s"))->load();
        p.release = apvts.getRawParameterValue (laneId (next, "r"))->load();
        e.setParameters (p);
        e.noteOn();
    }
    currentLane = next;
    activeLane = next;
    samplesToNextStep += currentStepLengthSamples ((int) (stepCount++ % 2));
}

void ChaosTriggerProcessor::startNote (bool retrigger)
{
    if (retrigger || ! running)
        for (auto& p : lanePos) p = 0.0;
    for (auto& e : env) e.noteOff();
    currentLane = -1;
    stepIndex = 0;
    stepCount = 0;
    samplesToNextStep = 0.0;
    running = true;
}

void ChaosTriggerProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals nd;
    buffer.clear();
    const int numSamples = buffer.getNumSamples();
    if (laneBuf.getNumSamples() < numSamples) laneBuf.setSize (kNumLanes * 2, numSamples, false, false, true);
    laneBuf.clear();

    // Snapshot samples and per-lane settings for this block
    std::array<std::shared_ptr<const LaneSample>, kNumLanes> smp;
    std::array<bool, kNumLanes> mono {}, rev {};
    for (int i = 0; i < kNumLanes; ++i)
    {
        smp[(size_t) i] = std::atomic_load (&samples[(size_t) i]);
        mono[(size_t) i] = apvts.getRawParameterValue (laneId (i, "mono"))->load() > 0.5f;
        rev[(size_t) i]  = apvts.getRawParameterValue (laneId (i, "rev"))->load() > 0.5f;
        const bool on = apvts.getRawParameterValue (laneId (i, "power"))->load() > 0.5f;
        const float g = on ? juce::Decibels::decibelsToGain (apvts.getRawParameterValue (laneId (i, "vol"))->load(), -59.9f) : 0.0f;
        const float pan = apvts.getRawParameterValue (laneId (i, "pan"))->load();
        const float ang = (pan + 1.0f) * juce::MathConstants<float>::pi * 0.25f;
        gainL[(size_t) i].setTargetValue (g * std::cos (ang) * juce::MathConstants<float>::sqrt2);
        gainR[(size_t) i].setTargetValue (g * std::sin (ang) * juce::MathConstants<float>::sqrt2);
    }

    const bool legato = apvts.getRawParameterValue ("legato")->load() > 0.5f;
    const double pitchRatio = std::pow (2.0, apvts.getRawParameterValue ("pitch")->load() / 12.0);

    // Destination bus per lane: its own bus if enabled, otherwise the main bus.
    std::array<float*, kNumLanes> outL {}, outR {};
    for (int i = 0; i < kNumLanes; ++i)
    {
        int bus = i;
        if (i >= getBusCount (false) || getBus (false, i) == nullptr || ! getBus (false, i)->isEnabled())
            bus = 0;
        auto b = getBusBuffer (buffer, false, bus);
        outL[(size_t) i] = b.getNumChannels() > 0 ? b.getWritePointer (0) : nullptr;
        outR[(size_t) i] = b.getNumChannels() > 1 ? b.getWritePointer (1) : outL[(size_t) i];
    }

    auto midiIt = midi.cbegin();
    for (int n = 0; n < numSamples; ++n)
    {
        for (; midiIt != midi.cend() && (*midiIt).samplePosition <= n; ++midiIt)
        {
            const auto m = (*midiIt).getMessage();
            if (m.isNoteOn())
            {
                const bool first = heldNotes == 0;
                ++heldNotes;
                if (first || ! legato)
                    startNote (! legato || ! running);
                else
                {   // legato: restart step sequencer only
                    stepIndex = 0; stepCount = 0; samplesToNextStep = 0.0;
                }
            }
            else if (m.isNoteOff())
            {
                heldNotes = juce::jmax (0, heldNotes - 1);
                if (heldNotes == 0)
                {
                    for (auto& e : env) e.noteOff();
                    currentLane = -1;
                    activeLane = -1;
                }
            }
            else if (m.isAllNotesOff() || m.isAllSoundOff())
            {
                heldNotes = 0;
                for (auto& e : env) e.reset();
                running = false; currentLane = -1; activeLane = -1;
            }
        }

        if (! running) continue;

        if (heldNotes > 0)
        {
            samplesToNextStep -= 1.0;
            if (samplesToNextStep <= 0.0)
                advanceStep();
        }

        bool anyActive = heldNotes > 0;
        for (int i = 0; i < kNumLanes; ++i)
        {
            const auto& s = smp[(size_t) i];
            auto& e = env[(size_t) i];
            if (s == nullptr) continue;

            const int len = s->buffer.getNumSamples();
            const double inc = pitchRatio * s->sampleRate / sr;
            double& pos = lanePos[(size_t) i];

            if (e.isActive())
            {
                anyActive = true;
                const float a = e.getNextSample();
                double rp = rev[(size_t) i] ? (len - 1 - pos) : pos;
                rp = juce::jlimit (0.0, (double) (len - 1), rp);
                const int i0 = (int) rp;
                const int i1 = juce::jmin (len - 1, i0 + 1);
                const float fr = (float) (rp - i0);
                const float* L = s->buffer.getReadPointer (0);
                const float* R = s->buffer.getReadPointer (1);
                float l = L[i0] + fr * (L[i1] - L[i0]);
                float r = R[i0] + fr * (R[i1] - R[i0]);
                if (mono[(size_t) i]) l = r = 0.5f * (l + r);
                laneBuf.setSample (i * 2, n, l * a);
                laneBuf.setSample (i * 2 + 1, n, r * a);
            }
            // All lanes run in parallel so every step lands at the matching spot in its loop.
            pos += inc;
            if (pos >= len) pos = std::fmod (pos, (double) len);
        }
        if (! anyActive) running = false;
    }

    // Lane FX -> pan/volume -> lane output bus
    std::array<bool, kNumLanes> busUsed {};
    for (int i = 0; i < kNumLanes; ++i)
    {
        float* L = laneBuf.getWritePointer (i * 2);
        float* R = laneBuf.getWritePointer (i * 2 + 1);
        laneFx[(size_t) i].process (L, R, numSamples, readFx (laneId (i, ""), false));
        for (int n = 0; n < numSamples; ++n)
        {
            const float gl = gainL[(size_t) i].getNextValue(), gr = gainR[(size_t) i].getNextValue();
            if (outL[(size_t) i]) outL[(size_t) i][n] += L[n] * gl;
            if (outR[(size_t) i] && outR[(size_t) i] != outL[(size_t) i]) outR[(size_t) i][n] += R[n] * gr;
        }
    }
    // Master FX on every active output bus (same settings on each)
    const auto mfx = readFx ("m_", true);
    for (int b = 0; b < juce::jmin (kNumLanes, getBusCount (false)); ++b)
    {
        if (getBus (false, b) == nullptr || ! getBus (false, b)->isEnabled()) continue;
        auto bb = getBusBuffer (buffer, false, b);
        if (bb.getNumChannels() >= 2)
            masterFx[(size_t) b].process (bb.getWritePointer (0), bb.getWritePointer (1), numSamples, mfx);
    }
    juce::ignoreUnused (busUsed);

    for (int i = 0; i < kNumLanes; ++i)
    {
        const auto& s = smp[(size_t) i];
        playPos[(size_t) i] = (s != nullptr && s->buffer.getNumSamples() > 0)
            ? (float) ((rev[(size_t) i] ? s->buffer.getNumSamples() - lanePos[(size_t) i] : lanePos[(size_t) i]) / s->buffer.getNumSamples())
            : 0.0f;
        envLevel[(size_t) i] = env[(size_t) i].isActive() ? 1.0f : 0.0f;
    }
}

void ChaosTriggerProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    auto state = apvts.copyState();
    for (int i = 0; i < kNumLanes; ++i)
        if (auto s = getSample (i))
            state.setProperty ("sample" + juce::String (i), s->path, nullptr);
    if (auto xml = state.createXml())
        copyXmlToBinary (*xml, dest);
}

void ChaosTriggerProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
    {
        auto tree = juce::ValueTree::fromXml (*xml);
        if (! tree.isValid()) return;
        apvts.replaceState (tree);
        for (int i = 0; i < kNumLanes; ++i)
        {
            juce::File f (tree.getProperty ("sample" + juce::String (i)).toString());
            if (f.existsAsFile()) loadSample (i, f);
        }
    }
}

juce::AudioProcessorEditor* ChaosTriggerProcessor::createEditor() { return new ChaosTriggerEditor (*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new ChaosTriggerProcessor(); }
